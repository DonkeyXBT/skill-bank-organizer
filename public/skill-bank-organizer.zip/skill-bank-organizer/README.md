# Skill Bank Organizer

A RuneLite plugin that scans your bank and splits it into **one page per skill**.

Each page shows:

- The best tools you already have (and what’s next)
- Training methods and the supplies those methods need
- Every matching stack currently in the bank
- A **rebuild order** — drag items into that order by hand. The plugin never moves your bank for you.
- **Right-click → Send to [skill]** on a bank item. That opens the matching page and writes a Bank Tag (`#woodcutting`, `#raids`, …). Jagex does not allow plugins to drag items; you still move the stack yourself.
- A **Raids** page for CoX / ToB / ToA kits.

## Install (sideload while developing)

1. Install [IntelliJ IDEA](https://www.jetbrains.com/idea/) and JDK 11+.
2. **File → Open** this folder (`skill-bank-organizer`) as a Gradle project.
3. Wait for Gradle sync, then run the `run` Gradle task (or `SkillBankOrganizerPluginTest`).
4. Log in with a [Jagex account](https://github.com/runelite/runelite/wiki/Using-Jagex-Accounts) if you use one.
5. Enable **Skill Bank Organizer** in the sidebar plugin list.
6. Open your bank. Pages fill from the live container. Right-click any stack → **Send to Woodcutting** (or Raids, Magic, …). That tags it and opens the page. Drag it onto the tab yourself.

Suggested bank tabs are listed on the home page (Melee, Ranged, Magic, Prayer, …). Put a placeholder gap between skills so the layout stays put.

## Plugin Hub

This project follows the [example-plugin](https://github.com/runelite/example-plugin) layout. To submit: publish the repo and open a PR against [runelite/plugin-hub](https://github.com/runelite/plugin-hub).

## Notes

- Items can appear on more than one skill (logs sit on Woodcutting, Firemaking and Fletching).
- Unmatched stacks land on **Uncategorized** (tab 9).
- Nothing is automated. No clicking, no moving items — information only.
